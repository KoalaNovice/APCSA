/*
Colin Finney
Period 4
Mrs. Woldseth 
APCSA 1
11/27/2021

Numbers Riddle Program
 */
public class NumbersRiddle
{
  public static void main(String[]args)
  {
    /* Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!
    Note same algorithm used for all just variable names change accordingly 
    Variable list:
    finalNumber  
    posInt
    negInt
    zero
    one
    posDouble
    negDouble
    */
    /* Postive integer example */
    double posInt = 5;
    System.out.println("Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!");
    System.out.println("Proving this if you choose: " + posInt);
    double finalNumber = 2 * posInt;
    System.out.println(finalNumber);
    finalNumber += 6;
    System.out.println(finalNumber);
    finalNumber /= 2;
    System.out.println(finalNumber);
    finalNumber -= posInt;
    System.out.println(finalNumber);
    System.out.println("The result is: " + (int) finalNumber);
    
    /* Negative integer example */
    double negInt = -5;
    System.out.println("Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!");
    System.out.println("Proving this if you choose: " + negInt);
    finalNumber = 2 * negInt;
    System.out.println(finalNumber);
    finalNumber += 6;
    System.out.println(finalNumber);
    finalNumber /= 2;
    System.out.println(finalNumber);
    finalNumber -= negInt;
    System.out.println(finalNumber);
    System.out.println("The result is: " + (int) finalNumber);
    
    /* Zero example */
    double zero = 0;
    System.out.println("Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!");
    System.out.println("Proving this if you choose: " + zero);
    finalNumber = 2 * zero;
    System.out.println(finalNumber);
    finalNumber += 6;
    System.out.println(finalNumber);
    finalNumber /= 2;
    System.out.println(finalNumber);
    finalNumber -= zero;
    System.out.println(finalNumber);
    System.out.println("The result is: " + (int) finalNumber);
    
    
    /* One example */
    double one = 1;
    System.out.println("Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!");
    System.out.println("Proving this if you choose: " + one);
    finalNumber = 2 * one;
    System.out.println(finalNumber);
    finalNumber += 6;
    System.out.println(finalNumber);
    finalNumber /= 2;
    System.out.println(finalNumber);
    finalNumber -= one;
    System.out.println(finalNumber);
    System.out.println("The result is: " + (int) finalNumber);
    
    /* Positive double example */
    double posDouble = 5.5;
    System.out.println("Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!");
    System.out.println("Proving this if you choose: " + posDouble);
    finalNumber = 2 * posDouble;
    System.out.println(finalNumber);
    finalNumber += 6;
    System.out.println(finalNumber);
    finalNumber /= 2;
    System.out.println(finalNumber);
    finalNumber -= posDouble;
    System.out.println(finalNumber);
    System.out.println("The result is: " + (int) finalNumber);
    
    /* Negative double example */
    double negDouble = -5.5;
    System.out.println("Choose any integer, double it, add six, divide it in half, and subtract the number you started with. The answer is always three!");
    System.out.println("Proving this if you choose: " + negDouble);
    finalNumber = 2 * negDouble;
    System.out.println(finalNumber);
    finalNumber += 6;
    System.out.println(finalNumber);
    finalNumber /= 2;
    System.out.println(finalNumber);
    finalNumber -= negDouble;
    System.out.println(finalNumber);
    System.out.println("The result is: " + (int) finalNumber);
  }
}
